//js没有replaceAll方法，添加 Stirng对象的原型方法
String.prototype.replaceAll = function(s1, s2) {
	return this.replace(new RegExp(s1, "gm"), s2);
};
// to convert special char to responding ASCII
function convertToAscii(str) {
	str = str.replace(/\%/g, "%25");
	str = str.replace(/\&/g, "%26");
	str = str.replace(/\#/g, "%23");
	str = str.replace(/\+/g, "%2B");// ascii for "+"
	return str;
}

// to restore ASCII to special char
function restoreFromAscii(str) {
	str = str.replaceAll("%20", " ");
	str = str.replaceAll("%26", "&");
	str = str.replaceAll("%2F", "/");
	str = str.replaceAll("%2C", ",");
	str = str.replaceAll("%23", "#");
	str = str.replaceAll("%2B", "+");
	str = str.replaceAll("%40", "@");
	return str;
}

// restore char "+" from java
function restorePlus(str) {
	str = str.replaceAll("%2B", " ");
	return str;
}

// overwrite the encodeURI function
function myEncodeURI(unzipStr, isCusEncode) {
	if (isCusEncode) {
		var zipArray = new Array();
		var zipstr = "";
		var lens = new Array();
		for ( var i = 0; i < unzipStr.length; i++) {
			var ac = unzipStr.charCodeAt(i);// 返回指定位置的字符的 Unicode 编码
			zipstr += ac;
			lens = lens.concat(ac.toString().length);
		}
		zipArray = zipArray.concat(zipstr);
		zipArray = zipArray.concat(lens.join("O"));
		return zipArray.join("N");
	} else {
		// 特殊字符，return encodeURI(unzipStr);
		var zipstr = "";
		var strSpecial = "!\"#$%&'()*+,/:;<=>?[]^`{|}~%";
		var tt = "";
		for ( var i = 0; i < unzipStr.length; i++) {
			var chr = unzipStr.charAt(i);// 返回指定位置的字符子串
			var c = stringToAscii(chr);
			tt += chr + ":" + c + "n";
			if (parseInt("0x" + c) > 0x7f) {
				zipstr += encodeURI(unzipStr.substr(i, 1));
			} else {
				if (chr == " ")
					zipstr += "+";// change " " to "+" for java
				else if (strSpecial.indexOf(chr) != -1)
					zipstr += "%" + c.toString(16);
				else
					zipstr += chr;
			}
		}
		return zipstr;
	}
}

// overwrite the decodeURI function
function myDecodeURI(zipStr, isCusEncode) {
	if (isCusEncode) {
		var zipArray = zipStr.split("N");
		var zipSrcStr = zipArray[0];
		var zipLens;
		if (zipArray[1]) {
			zipLens = zipArray[1].split("O");
		} else {
			zipLens.length = 0;
		}

		var uzipStr = "";

		for ( var j = 0; j < zipLens.length; j++) {
			var charLen = parseInt(zipLens[j]);
			uzipStr += String.fromCharCode(zipSrcStr.substr(0, charLen));
			zipSrcStr = zipSrcStr.slice(charLen, zipSrcStr.length);
		}
		return uzipStr;
	} else {
		// return decodeURI(zipStr);
		var uzipStr = "";
		for ( var i = 0; i < zipStr.length; i++) {
			var chr = zipStr.charAt(i);
			if (chr == "+") {
				uzipStr += " ";// restore "+" back to " "
			} else if (chr == "%") {
				var asc = zipStr.substring(i + 1, i + 3);
				if (parseInt("0x" + asc) > 0x7f) {
					uzipStr += decodeURI("%" + asc.toString()
							+ zipStr.substring(i + 3, i + 9).toString());
					;
					i += 8;
				} else {
					uzipStr += asciiToString(parseInt("0x" + asc));
					i += 2;
				}
			} else {
				uzipStr += chr;
			}
		}
		return uzipStr;
	}
}

// convert string to ascii
function stringToAscii(str) {
	return str.charCodeAt(0).toString(16);
}

// convert ascii to string
function asciiToString(asccode) {
	return String.fromCharCode(asccode);
}