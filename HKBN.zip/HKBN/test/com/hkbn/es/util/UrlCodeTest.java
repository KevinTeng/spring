package com.hkbn.es.util;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class UrlCodeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testUrlEncode() {
		assertEquals("%26", UrlCode.urlEncode("&"));
		assertEquals("%20", UrlCode.urlEncode(" "));
	}

	@Test
	public void testUrlDecode() {
		assertEquals(5 + 6, 10);
	}

	@Test
	public void testUrlDecodeToUTF8() {
		assertSame(5, 5);
	}

	@Test
	public void testStringToUTF8() {
		// fail("Not yet implemented");
	}

}
