package com.hkbn.es.entity;

import java.util.Date;

/**
 * BcnAddrMaint entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class BcnAddrMaint implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long maintCode;
	private String buildCode;
	private String pps;
	private Long cusPlanCode;
	private String addr1;
	private String addr2;
	private String addr3;
	private String addr4;
	private String circuitNo;
	private Long lineNo;
	private Date startDate;
	private Date endDate;
	private String staffCreate;
	private String staffAmend;
	private Date createDate;
	private String currAddr;
	private String addrType;
	private String floor;
	private String flatRm;
	private Long addrCode;
	private Date amendDate;
	private String region;
	private String addr5;
	private Long item1Opt;
	private String item1Val;
	private Long item2Opt;
	private String item2Val;
	private Long item3Opt;
	private String item3Val;
	private Long item4Opt;
	private String item4Val;
	private Long item5Opt;
	private String item5Val;
	private String streetNo;
	private String correctMatch;
	private String block;
	private String contactPerson;
	private String telephone;
	private String company;

	// private Long contactCode;

	// Constructors

	/** default constructor */
	public BcnAddrMaint() {
	}

	/** minimal constructor */
	public BcnAddrMaint(Long maintCode) {
		this.maintCode = maintCode;
	}

	/** full constructor */
	public BcnAddrMaint(Long maintCode, String buildCode, String pps,
			Long cusPlanCode, String addr1, String addr2, String addr3,
			String addr4, String circuitNo, Long lineNo, Date startDate,
			Date endDate, String staffCreate, String staffAmend,
			Date createDate, String currAddr, String addrType, String floor,
			String flatRm, Long addrCode, Date amendDate, String region,
			String addr5, Long item1Opt, String item1Val, Long item2Opt,
			String item2Val, Long item3Opt, String item3Val, Long item4Opt,
			String item4Val, Long item5Opt, String item5Val, String streetNo,
			String correctMatch, String block, String contactPerson,
			String telephone, String company) {
		this.maintCode = maintCode;
		this.buildCode = buildCode;
		this.pps = pps;
		this.cusPlanCode = cusPlanCode;
		this.addr1 = addr1;
		this.addr2 = addr2;
		this.addr3 = addr3;
		this.addr4 = addr4;
		this.circuitNo = circuitNo;
		this.lineNo = lineNo;
		this.startDate = startDate;
		this.endDate = endDate;
		this.staffCreate = staffCreate;
		this.staffAmend = staffAmend;
		this.createDate = createDate;
		this.currAddr = currAddr;
		this.addrType = addrType;
		this.floor = floor;
		this.flatRm = flatRm;
		this.addrCode = addrCode;
		this.amendDate = amendDate;
		this.region = region;
		this.addr5 = addr5;
		this.item1Opt = item1Opt;
		this.item1Val = item1Val;
		this.item2Opt = item2Opt;
		this.item2Val = item2Val;
		this.item3Opt = item3Opt;
		this.item3Val = item3Val;
		this.item4Opt = item4Opt;
		this.item4Val = item4Val;
		this.item5Opt = item5Opt;
		this.item5Val = item5Val;
		this.streetNo = streetNo;
		this.correctMatch = correctMatch;
		this.block = block;
		this.contactPerson = contactPerson;
		this.telephone = telephone;
		this.company = company;
		// this.contactCode = contactCode;
	}

	// Property accessors

	public Long getMaintCode() {
		return this.maintCode;
	}

	public void setMaintCode(Long maintCode) {
		this.maintCode = maintCode;
	}

	public String getBuildCode() {
		return this.buildCode;
	}

	public void setBuildCode(String buildCode) {
		this.buildCode = buildCode;
	}

	public String getPps() {
		return this.pps;
	}

	public void setPps(String pps) {
		this.pps = pps;
	}

	public Long getCusPlanCode() {
		return this.cusPlanCode;
	}

	public void setCusPlanCode(Long cusPlanCode) {
		this.cusPlanCode = cusPlanCode;
	}

	public String getAddr1() {
		return this.addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return this.addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return this.addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public String getAddr4() {
		return this.addr4;
	}

	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}

	public String getCircuitNo() {
		return this.circuitNo;
	}

	public void setCircuitNo(String circuitNo) {
		this.circuitNo = circuitNo;
	}

	public Long getLineNo() {
		return this.lineNo;
	}

	public void setLineNo(Long lineNo) {
		this.lineNo = lineNo;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getStaffCreate() {
		return this.staffCreate;
	}

	public void setStaffCreate(String staffCreate) {
		this.staffCreate = staffCreate;
	}

	public String getStaffAmend() {
		return this.staffAmend;
	}

	public void setStaffAmend(String staffAmend) {
		this.staffAmend = staffAmend;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCurrAddr() {
		return this.currAddr;
	}

	public void setCurrAddr(String currAddr) {
		this.currAddr = currAddr;
	}

	public String getAddrType() {
		return this.addrType;
	}

	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}

	public String getFloor() {
		return this.floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getFlatRm() {
		return this.flatRm;
	}

	public void setFlatRm(String flatRm) {
		this.flatRm = flatRm;
	}

	public Long getAddrCode() {
		return this.addrCode;
	}

	public void setAddrCode(Long addrCode) {
		this.addrCode = addrCode;
	}

	public Date getAmendDate() {
		return this.amendDate;
	}

	public void setAmendDate(Date amendDate) {
		this.amendDate = amendDate;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getAddr5() {
		return this.addr5;
	}

	public void setAddr5(String addr5) {
		this.addr5 = addr5;
	}

	public Long getItem1Opt() {
		return this.item1Opt;
	}

	public void setItem1Opt(Long item1Opt) {
		this.item1Opt = item1Opt;
	}

	public String getItem1Val() {
		return this.item1Val;
	}

	public void setItem1Val(String item1Val) {
		this.item1Val = item1Val;
	}

	public Long getItem2Opt() {
		return this.item2Opt;
	}

	public void setItem2Opt(Long item2Opt) {
		this.item2Opt = item2Opt;
	}

	public String getItem2Val() {
		return this.item2Val;
	}

	public void setItem2Val(String item2Val) {
		this.item2Val = item2Val;
	}

	public Long getItem3Opt() {
		return this.item3Opt;
	}

	public void setItem3Opt(Long item3Opt) {
		this.item3Opt = item3Opt;
	}

	public String getItem3Val() {
		return this.item3Val;
	}

	public void setItem3Val(String item3Val) {
		this.item3Val = item3Val;
	}

	public Long getItem4Opt() {
		return this.item4Opt;
	}

	public void setItem4Opt(Long item4Opt) {
		this.item4Opt = item4Opt;
	}

	public String getItem4Val() {
		return this.item4Val;
	}

	public void setItem4Val(String item4Val) {
		this.item4Val = item4Val;
	}

	public Long getItem5Opt() {
		return this.item5Opt;
	}

	public void setItem5Opt(Long item5Opt) {
		this.item5Opt = item5Opt;
	}

	public String getItem5Val() {
		return this.item5Val;
	}

	public void setItem5Val(String item5Val) {
		this.item5Val = item5Val;
	}

	public String getStreetNo() {
		return this.streetNo;
	}

	public void setStreetNo(String streetNo) {
		this.streetNo = streetNo;
	}

	public String getCorrectMatch() {
		return this.correctMatch;
	}

	public void setCorrectMatch(String correctMatch) {
		this.correctMatch = correctMatch;
	}

	public String getBlock() {
		return this.block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getContactPerson() {
		return this.contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

}