package com.hkbn.es.entity;

import java.util.Date;

/**
 * BcCus entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class BcCus implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pps;
	private String company;
	private String brno;
	private Date createDate;
	private Date amendDate;
	private String staffCreate;
	private String staffAmend;
	private String program;
	private String ctiCusType;
	private String ctiOd;
	private String telephone;
	private String iddAc;
	private Long creLimit;
	private String previousIsp;
	private String prevIntConn;
	private String status;
	private Long vip;
	private String companyChinese;
	private String tender;
	private String premium;
	private String nickname;
	private String wholesaleFlag;

	// Constructors

	/** default constructor */
	public BcCus() {
	}

	/** minimal constructor */
	public BcCus(String pps, String company, Date createDate,
			String staffCreate, String program, String ctiCusType, String ctiOd) {
		this.pps = pps;
		this.company = company;
		this.createDate = createDate;
		this.staffCreate = staffCreate;
		this.program = program;
		this.ctiCusType = ctiCusType;
		this.ctiOd = ctiOd;
	}

	/** full constructor */
	public BcCus(String pps, String company, String brno, Date createDate,
			Date amendDate, String staffCreate, String staffAmend,
			String program, String ctiCusType, String ctiOd, String telephone,
			String iddAc, Long creLimit, String previousIsp,
			String prevIntConn, String status, Long vip, String companyChinese,
			String tender, String premium, String nickname, String wholesaleFlag) {
		this.pps = pps;
		this.company = company;
		this.brno = brno;
		this.createDate = createDate;
		this.amendDate = amendDate;
		this.staffCreate = staffCreate;
		this.staffAmend = staffAmend;
		this.program = program;
		this.ctiCusType = ctiCusType;
		this.ctiOd = ctiOd;
		this.telephone = telephone;
		this.iddAc = iddAc;
		this.creLimit = creLimit;
		this.previousIsp = previousIsp;
		this.prevIntConn = prevIntConn;
		this.status = status;
		this.vip = vip;
		this.companyChinese = companyChinese;
		this.tender = tender;
		this.premium = premium;
		this.nickname = nickname;
		this.wholesaleFlag = wholesaleFlag;
	}

	// Property accessors

	public String getPps() {
		return this.pps;
	}

	public void setPps(String pps) {
		this.pps = pps;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getBrno() {
		return this.brno;
	}

	public void setBrno(String brno) {
		this.brno = brno;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getAmendDate() {
		return this.amendDate;
	}

	public void setAmendDate(Date amendDate) {
		this.amendDate = amendDate;
	}

	public String getStaffCreate() {
		return this.staffCreate;
	}

	public void setStaffCreate(String staffCreate) {
		this.staffCreate = staffCreate;
	}

	public String getStaffAmend() {
		return this.staffAmend;
	}

	public void setStaffAmend(String staffAmend) {
		this.staffAmend = staffAmend;
	}

	public String getProgram() {
		return this.program;
	}

	public void setProgram(String program) {
		this.program = program;
	}

	public String getCtiCusType() {
		return this.ctiCusType;
	}

	public void setCtiCusType(String ctiCusType) {
		this.ctiCusType = ctiCusType;
	}

	public String getCtiOd() {
		return this.ctiOd;
	}

	public void setCtiOd(String ctiOd) {
		this.ctiOd = ctiOd;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getIddAc() {
		return this.iddAc;
	}

	public void setIddAc(String iddAc) {
		this.iddAc = iddAc;
	}

	public Long getCreLimit() {
		return this.creLimit;
	}

	public void setCreLimit(Long creLimit) {
		this.creLimit = creLimit;
	}

	public String getPreviousIsp() {
		return this.previousIsp;
	}

	public void setPreviousIsp(String previousIsp) {
		this.previousIsp = previousIsp;
	}

	public String getPrevIntConn() {
		return this.prevIntConn;
	}

	public void setPrevIntConn(String prevIntConn) {
		this.prevIntConn = prevIntConn;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getVip() {
		return this.vip;
	}

	public void setVip(Long vip) {
		this.vip = vip;
	}

	public String getCompanyChinese() {
		return this.companyChinese;
	}

	public void setCompanyChinese(String companyChinese) {
		this.companyChinese = companyChinese;
	}

	public String getTender() {
		return this.tender;
	}

	public void setTender(String tender) {
		this.tender = tender;
	}

	public String getPremium() {
		return this.premium;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getNickname() {
		return this.nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getWholesaleFlag() {
		return this.wholesaleFlag;
	}

	public void setWholesaleFlag(String wholesaleFlag) {
		this.wholesaleFlag = wholesaleFlag;
	}

}