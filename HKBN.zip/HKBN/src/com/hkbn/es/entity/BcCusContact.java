package com.hkbn.es.entity;

import java.util.Date;

/**
 * BcCusContact entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class BcCusContact implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long contactCode;
	private String pps;
	private String contactPerson;
	private String telephone;
	private String mobile;
	private String fax;
	private String emailAddress;
	private String type;
	private String staffCreate;
	private Date createDate;
	private String staffAmend;
	private Date amendDate;
	private String hkid;
	private String homeTel;

	// Constructors

	/** default constructor */
	public BcCusContact() {
	}

	/** minimal constructor */
	public BcCusContact(Long contactCode, String pps, String contactPerson,
			String type, String staffCreate, Date createDate) {
		this.contactCode = contactCode;
		this.pps = pps;
		this.contactPerson = contactPerson;
		this.type = type;
		this.staffCreate = staffCreate;
		this.createDate = createDate;
	}

	/** full constructor */
	public BcCusContact(Long contactCode, String pps, String contactPerson,
			String telephone, String mobile, String fax, String emailAddress,
			String type, String staffCreate, Date createDate,
			String staffAmend, Date amendDate, String hkid, String homeTel) {
		this.contactCode = contactCode;
		this.pps = pps;
		this.contactPerson = contactPerson;
		this.telephone = telephone;
		this.mobile = mobile;
		this.fax = fax;
		this.emailAddress = emailAddress;
		this.type = type;
		this.staffCreate = staffCreate;
		this.createDate = createDate;
		this.staffAmend = staffAmend;
		this.amendDate = amendDate;
		this.hkid = hkid;
		this.homeTel = homeTel;
	}

	// Property accessors

	public Long getContactCode() {
		return this.contactCode;
	}

	public void setContactCode(Long contactCode) {
		this.contactCode = contactCode;
	}

	public String getPps() {
		return this.pps;
	}

	public void setPps(String pps) {
		this.pps = pps;
	}

	public String getContactPerson() {
		return this.contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStaffCreate() {
		return this.staffCreate;
	}

	public void setStaffCreate(String staffCreate) {
		this.staffCreate = staffCreate;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getStaffAmend() {
		return this.staffAmend;
	}

	public void setStaffAmend(String staffAmend) {
		this.staffAmend = staffAmend;
	}

	public Date getAmendDate() {
		return this.amendDate;
	}

	public void setAmendDate(Date amendDate) {
		this.amendDate = amendDate;
	}

	public String getHkid() {
		return this.hkid;
	}

	public void setHkid(String hkid) {
		this.hkid = hkid;
	}

	public String getHomeTel() {
		return this.homeTel;
	}

	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}

}