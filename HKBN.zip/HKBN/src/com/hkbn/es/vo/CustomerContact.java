package com.hkbn.es.vo;

import java.util.List;

import com.hkbn.es.entity.BcCus;
import com.hkbn.es.util.StringUtil;

public class CustomerContact {
	private String txn_id;
	private String resp_sts;
	private String pps;
	private String brno;
	private String cus_status;
	private String company;
	private String company_chinese;
	private String nickname;
	private String telephone;
	private String idd_ac;
	private String vip;
	private String wholesale_flag;
	private String premium;
	private String tender;
	private String cti_od;
	private String cti_cus_type;
	private String cust_ls_status;
	private List<Contact> contact;

	public String getTxn_id() {
		return StringUtil.changeNull(txn_id);
	}

	public void setTxn_id(String txn_id) {
		this.txn_id = txn_id;
	}

	public String getResp_sts() {
		return StringUtil.changeNull(resp_sts);
	}

	public void setResp_sts(String resp_sts) {
		this.resp_sts = resp_sts;
	}

	public String getPps() {
		return StringUtil.changeNull(pps);
	}

	public void setPps(String pps) {
		this.pps = pps;
	}

	public String getBrno() {
		return StringUtil.changeNull(brno);
	}

	public void setBrno(String brno) {
		this.brno = brno;
	}

	public String getCus_status() {
		return StringUtil.changeNull(cus_status);
	}

	public void setCus_status(String cus_status) {
		this.cus_status = cus_status;
	}

	public String getCompany() {
		return StringUtil.changeNull(company);
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCompany_chinese() {
		return StringUtil.changeNull(company_chinese);
	}

	public void setCompany_chinese(String company_chinese) {
		this.company_chinese = company_chinese;
	}

	public String getNickname() {
		return StringUtil.changeNull(nickname);
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getTelephone() {
		return StringUtil.changeNull(telephone);
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getIdd_ac() {
		return StringUtil.changeNull(idd_ac);
	}

	public void setIdd_ac(String idd_ac) {
		this.idd_ac = idd_ac;
	}

	public String getVip() {
		return StringUtil.changeNull(vip);
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	public String getWholesale_flag() {
		return StringUtil.changeNull(wholesale_flag);
	}

	public void setWholesale_flag(String wholesale_flag) {
		this.wholesale_flag = wholesale_flag;
	}

	public String getPremium() {
		return StringUtil.changeNull(premium);
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getTender() {
		return StringUtil.changeNull(tender);
	}

	public void setTender(String tender) {
		this.tender = tender;
	}

	public String getCti_od() {
		return StringUtil.changeNull(cti_od);
	}

	public void setCti_od(String cti_od) {
		this.cti_od = cti_od;
	}

	public String getCti_cus_type() {
		return StringUtil.changeNull(cti_cus_type);
	}

	public void setCti_cus_type(String cti_cus_type) {
		this.cti_cus_type = cti_cus_type;
	}

	public String getCust_ls_status() {
		return StringUtil.changeNull(cust_ls_status);
	}

	public void setCust_ls_status(String cust_ls_status) {
		this.cust_ls_status = cust_ls_status;
	}

	public List<Contact> getContact() {
		return contact;
	}

	public void setContact(List<Contact> contact) {
		this.contact = contact;
	}

	public static CustomerContact BcCus_To_CustomerContact(CustomerContact cus,
			BcCus bc) {
		if (cus == null) {
			cus = new CustomerContact();
		}
		cus.setPps(bc.getPps());
		cus.setBrno(bc.getBrno());
		// cus.setCus_status(bc.getStatus());
		cus.setCompany(bc.getCompany());
		cus.setCompany_chinese(bc.getCompanyChinese());
		cus.setNickname(bc.getNickname());
		cus.setTelephone(bc.getTelephone());
		cus.setIdd_ac(bc.getIddAc());
		cus.setVip(bc.getVip() + "");
		cus.setWholesale_flag(bc.getWholesaleFlag());
		cus.setPremium(bc.getPremium());
		cus.setTender(bc.getTender());
		cus.setCti_od(bc.getCtiOd());
		// cus.setCti_cus_type(bc.getCtiCusType());
		return cus;
	}
}
