package com.hkbn.es.vo;

//import javax.xml.bind.annotation.XmlRootElement;

import com.hkbn.es.util.StringUtil;

//@XmlRootElement
public class Option
{

	private String option_ref;
	private String option_value;

	public String getOption_ref()
	{
		return StringUtil.changeNull(option_ref);
	}

	public void setOption_ref(String option_ref)
	{
		this.option_ref = option_ref;
	}

	public String getOption_value()
	{
		return StringUtil.changeNull(option_value);
	}

	public void setOption_value(String option_value)
	{
		this.option_value = option_value;
	}

}
