package com.hkbn.es.vo;

import com.hkbn.es.entity.BcnAddrMaint;
import com.hkbn.es.util.DateUtil;
import com.hkbn.es.util.StringUtil;

public class Address {
	private String addr_type;
	private String addr1;
	private String addr2;
	private String addr3;
	private String addr4;
	private String correct_match_desc;
	private String buildcode_display;
	private String building_statu;
	private String contact_person;
	private String cust_plan_code;
	private String plan_status;
	private String plan_code;
	private String circuit_no;
	private String dis_line_no;
	private String start_date;
	private String end_date;
	private String telephone;
	private String company;
	private String plan_addr;

	public static Address BcnAddrMaint_To_Address(Address addr, BcnAddrMaint bam) {
		if (addr == null) {
			addr = new Address();
		}
		addr.setAddr_type(bam.getAddrType());
		addr.setAddr1(bam.getAddr1());
		addr.setAddr2(bam.getAddr2());
		addr.setAddr3(bam.getAddr3());
		addr.setAddr4(bam.getAddr4());
		// addr.setCorrect_match_desc(correct_match_desc);
		addr.setBuildcode_display(bam.getBuildCode());
		// addr.setBuilding_statu(building_statu);
		addr.setContact_person(bam.getContactPerson());
		addr.setCust_plan_code(bam.getCusPlanCode() + "");
		// addr.setPlan_status(plan_status);
		// addr.setPlan_code(plan_code);
		addr.setCircuit_no(bam.getCircuitNo());
		// addr.setDis_line_no(dis_line_no);
		addr.setStart_date(DateUtil.formattime(bam.getStartDate(), "yyyy/MM/dd"));
		addr.setEnd_date(DateUtil.formattime(bam.getEndDate(), "yyyy/MM/dd"));
		addr.setTelephone(bam.getTelephone());
		addr.setCompany(bam.getCompany());
		// addr.setPlan_addr(plan_addr);

		return addr;

	}

	public String getAddr_type() {
		return StringUtil.changeNull(addr_type);
	}

	public void setAddr_type(String addr_type) {
		this.addr_type = addr_type;
	}

	public String getAddr1() {
		return StringUtil.changeNull(addr1);
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return StringUtil.changeNull(addr2);
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return StringUtil.changeNull(addr3);
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public String getAddr4() {
		return StringUtil.changeNull(addr4);
	}

	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}

	public String getCorrect_match_desc() {
		return StringUtil.changeNull(correct_match_desc);
	}

	public void setCorrect_match_desc(String correct_match_desc) {
		this.correct_match_desc = correct_match_desc;
	}

	public String getBuildcode_display() {
		return StringUtil.changeNull(buildcode_display);
	}

	public void setBuildcode_display(String buildcode_display) {
		this.buildcode_display = buildcode_display;
	}

	public String getBuilding_statu() {
		return StringUtil.changeNull(building_statu);
	}

	public void setBuilding_statu(String building_statu) {
		this.building_statu = building_statu;
	}

	public String getContact_person() {
		return StringUtil.changeNull(contact_person);
	}

	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	public String getCust_plan_code() {
		return StringUtil.changeNull(cust_plan_code);
	}

	public void setCust_plan_code(String cust_plan_code) {
		this.cust_plan_code = cust_plan_code;
	}

	public String getPlan_status() {
		return StringUtil.changeNull(plan_status);
	}

	public void setPlan_status(String plan_status) {
		this.plan_status = plan_status;
	}

	public String getPlan_code() {
		return StringUtil.changeNull(plan_code);
	}

	public void setPlan_code(String plan_code) {
		this.plan_code = plan_code;
	}

	public String getCircuit_no() {
		return StringUtil.changeNull(circuit_no);
	}

	public void setCircuit_no(String circuit_no) {
		this.circuit_no = circuit_no;
	}

	public String getDis_line_no() {
		return StringUtil.changeNull(dis_line_no);
	}

	public void setDis_line_no(String dis_line_no) {
		this.dis_line_no = dis_line_no;
	}

	public String getStart_date() {
		return StringUtil.changeNull(start_date);
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return StringUtil.changeNull(end_date);
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getTelephone() {
		return StringUtil.changeNull(telephone);
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getCompany() {
		return StringUtil.changeNull(company);
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPlan_addr() {
		return StringUtil.changeNull(plan_addr);
	}

	public void setPlan_addr(String plan_addr) {
		this.plan_addr = plan_addr;
	}

}
