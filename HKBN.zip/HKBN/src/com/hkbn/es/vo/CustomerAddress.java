package com.hkbn.es.vo;

import java.util.List;

import com.hkbn.es.util.StringUtil;

public class CustomerAddress {
	private String txn_id;
	private String resp_sts;
	private String pps;
	private List<Address> addresses;

	public String getTxn_id() {
		return StringUtil.changeNull(txn_id);
	}

	public void setTxn_id(String txn_id) {
		this.txn_id = txn_id;
	}

	public String getResp_sts() {
		return StringUtil.changeNull(resp_sts);
	}

	public void setResp_sts(String resp_sts) {
		this.resp_sts = resp_sts;
	}

	public String getPps() {
		return StringUtil.changeNull(pps);
	}

	public void setPps(String pps) {
		this.pps = pps;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

}
