package com.hkbn.es.vo;

import com.hkbn.es.entity.BcCusContact;
import com.hkbn.es.util.StringUtil;

public class Contact {
	private String type;
	private String contact_person;
	private String hkid;
	private String telephone;
	private String mobile;
	private String fax;
	private String email_address;
	private String uemo_sts;

	public String getType() {
		return StringUtil.changeNull(type);
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContact_person() {
		return StringUtil.changeNull(contact_person);
	}

	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	public String getHkid() {
		return StringUtil.changeNull(hkid);
	}

	public void setHkid(String hkid) {
		this.hkid = hkid;
	}

	public String getTelephone() {
		return StringUtil.changeNull(telephone);
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getMobile() {
		return StringUtil.changeNull(mobile);
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getFax() {
		return StringUtil.changeNull(fax);
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail_address() {
		return StringUtil.changeNull(email_address);
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public String getUemo_sts() {
		return StringUtil.changeNull(uemo_sts);
	}

	public void setUemo_sts(String uemo_sts) {
		this.uemo_sts = uemo_sts;
	}

	public static Contact BcCusContact_To_Contact(Contact co, BcCusContact bcc) {
		if (co == null) {
			co = new Contact();
		}
		// co.setType(bcc.getType());
		co.setContact_person(bcc.getContactPerson());
		co.setHkid(bcc.getHkid());
		co.setTelephone(bcc.getTelephone());
		co.setMobile(bcc.getMobile());
		co.setFax(bcc.getFax());
		co.setEmail_address(bcc.getEmailAddress());
		// co.setUemo_sts(bcc.get)
		return co;

	}
}
