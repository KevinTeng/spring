package com.hkbn.es.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hkbn.es.dao.impl.BaseDaoImpl;
import com.hkbn.es.service.BaseService;
import com.hkbn.es.vo.CusOpt;
import com.hkbn.es.vo.Option;

public class CusOptServiceImpl implements BaseService {
	private BaseDaoImpl dao;

	public BaseDaoImpl getDao() {
		return dao;
	}

	public void setDao(BaseDaoImpl dao) {
		this.dao = dao;
	}

	public CusOpt getResult(Map<String, Object> map)// 根據map查詢需要的數據
	{
		CusOpt co = null;// 定義返回的變量
		List<Option> list_Contact = null;// 定義返回的變量的其中一個屬性

		String sql = null;
		Object[] values = null;// 定義“參數列表”
		List list = null;
		if (map.size() == 0) {
			return null;
		} else {
			sql = "SELECT t.opt_ref as option_ref , t.opt_value as option_value FROM bc_cus_opt o,bc_opt_type t  WHERE 1=1 AND o.opt_code = t.opt_code AND o.pps = ? ";// 定義失sql語句
			values = new Object[map.size()];// 根據參數條件的數量創建“參數列表”
			int num = 0;
			Set<String> keys = map.keySet();
			Iterator<String> iterator = keys.iterator();
			while (iterator.hasNext())// 迭代key
			{
				String s = iterator.next();
				values[num] = map.get(s);
				num++;
			}
			try {
				list = dao.findBySql(sql, values);// 根據sql語句和參數列表查詢結果
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (list == null || list.size() == 0)// 如果沒有數據直接返回null
			{
				return null;
			} else {
				co = new CusOpt();// 創建返回對象
				list_Contact = new ArrayList<Option>();// 創建返回的變量的其中一個屬性
				for (int i = 0; i < list.size(); i++)// 循環list將數據庫對象轉換成輸出的對象
				{
					Map opt_map = (Map) list.get(i);// 從list中獲取返回結果
					Option opr = new Option();
					opr.setOption_ref((String) opt_map.get("option_ref"));// 根據map的key獲取value，插到返回對象的屬性中
					opr.setOption_value((String) opt_map.get("option_value"));// 根據map的key獲取value，插到返回對象的屬性中
					list_Contact.add(opr);
				}
				co.setOption(list_Contact);
				return co;
			}
		}

	}

}
