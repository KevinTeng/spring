package com.hkbn.es.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hkbn.es.dao.impl.BaseDaoImpl;
import com.hkbn.es.entity.BcCus;
import com.hkbn.es.entity.BcCusContact;
import com.hkbn.es.service.BaseService;
import com.hkbn.es.util.StringUtil;
import com.hkbn.es.vo.Contact;
import com.hkbn.es.vo.CustomerContact;

public class CusInfoServiceImpl implements BaseService {
	private BaseDaoImpl dao;

	public BaseDaoImpl getDao() {
		return dao;
	}

	public void setDao(BaseDaoImpl dao) {
		this.dao = dao;
	}

	public List getObject(Map<String, Object> map, String classname)// 根據map的參數和類名來查詢數據
	{
		String hql = null;// 定義hql語句
		Object[] values = null;// 定義“參數列表”
		StringBuffer sb_hqlBuffer = new StringBuffer("from " + classname
				+ " where 1=1 ");// 定義編輯前的hql語句
		int num = map.size();// 獲取有多少個參數條件
		values = new Object[num];// 根據參數條件的數量創建“參數列表”
		Set<String> keys = map.keySet();// 獲取map裡面所有的key
		Iterator<String> iterator = keys.iterator();// 迭代所有的key
		int i = 0;
		while (iterator.hasNext())// 迭代key
		{
			String s = iterator.next();
			sb_hqlBuffer.append(" and " + s + "=?");// 在hql中加入查詢條件
			values[i] = map.get(s);// “參數列表”修改該參數的值
			i++;
		}
		hql = sb_hqlBuffer.toString();// 生成hql語句
		List<Object> list = dao.find_by_hql(hql, values);// 根據hql語句和參數列表查詢結果
		return list;
	}

	public CustomerContact getResult(Map<String, Object> map)// 根據map查詢需要的數據
	{
		CustomerContact cus = null;// 定義返回的變量
		List<Contact> list_Contact = null;// 定義返回的變量的其中一個屬性

		String cus_status = null;// 定義返回的變量的其中一個屬性
		String cust_ls_status = null;// 定義返回的變量的其中一個屬性
		String sql = null;
		String type = null;// 定義返回的變量的其中一個屬性
		int uemo_sts_num = 0;
		String uemo_sts = null;

		if (map.size() == 0)// 判斷是否是條件參數，如果沒有直接返回null
		{
			return null;
		} else {
			List<BcCus> list = getObject(map, "BcCus");// 根據map的參數和類名來查詢數據
			if (list == null || list.size() != 1 || list.get(0) == null)// 如果沒有數據或多於一條數據直接返回null
			{
				return null;
			} else {
				BcCus bcCus = list.get(0);// 結果應該只有一條數據
				cus = CustomerContact.BcCus_To_CustomerContact(cus, bcCus);// 將數據庫對象轉換成輸出的對象

				// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
				sql = "SELECT distinct REF.REMARK FROM V_BC_CUS_STATUS V,BC_STATUS_REF REF WHERE V.STATUS=REF.STATUS  AND V.PPS='"
						+ bcCus.getPps() + "'";// 定義sql
				try {
					cus_status = dao.getStringBySql(sql);// 執行sql返回一條字符串
				} catch (Exception e) {
					e.printStackTrace();
				}
				cus.setCus_status(cus_status);// 查到輸出對象中

				// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
				sql = "SELECT REF.REMARK FROM V_BC_CUS_STATUS V, BC_STATUS_REF REF WHERE V.LS_STATUS = REF.STATUS AND V.PPS = '"
						+ bcCus.getPps() + "'";// 定義sql
				try {
					cust_ls_status = dao.getStringBySql(sql);// 執行sql返回一條字符串
				} catch (Exception e) {
					e.printStackTrace();
					cust_ls_status = "";
				}
				cus.setCust_ls_status(cust_ls_status);// 查到輸出對象中

				Map map_conMap = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值
				map_conMap.put("pps", bcCus.getPps());// 把它放到map裡面
				List<BcCusContact> list_bc_con = getObject(map_conMap,
						"BcCusContact");// 根據map的參數和類名來查詢數據
				if (list_bc_con != null && list_bc_con.size() != 0)// 判斷list_bc_con查詢的結果，如果不為0
				{
					list_Contact = new ArrayList<Contact>();// 創建返回的變量的其中一個屬性的實例
				}
				for (int i = 0; i < list_bc_con.size(); i++)// 循環list_bc_con將數據庫對象轉換成輸出的對象
				{
					BcCusContact bcc = list_bc_con.get(i);// 獲取一個數據庫對象
					Contact co = null;// 定義一個輸出類型的對象
					co = Contact.BcCusContact_To_Contact(co, bcc);// 將數據庫對象轉換成輸出的對象

					// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
					sql = "select remark from bc_contact_ref where contact_type = '"
							+ bcc.getType() + "'";// 定義sql
					try {
						type = dao.getStringBySql(sql);// 執行sql返回一條字符串
					} catch (Exception e) {
						e.printStackTrace();
					}
					co.setType(type);// 查到輸出對象中

					// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
					if (StringUtil.notEmpty(bcc.getTelephone())
							|| StringUtil.notEmpty(bcc.getMobile())) {
						if (StringUtil.notEmpty(bcc.getTelephone())
								&& StringUtil.notEmpty(bcc.getMobile())) {
							sql = "select count(1) from brx_uemo where phone_no in('"
									+ bcc.getTelephone()
									+ "','"
									+ bcc.getMobile() + "')";// 定義sql
						} else if (StringUtil.notEmpty(bcc.getTelephone())
								&& !StringUtil.notEmpty(bcc.getMobile())) {
							sql = "select count(1) from brx_uemo where phone_no in('"
									+ bcc.getTelephone() + "')";// 定義sql
						} else if (!StringUtil.notEmpty(bcc.getTelephone())
								&& StringUtil.notEmpty(bcc.getMobile())) {
							sql = "select count(1) from brx_uemo where phone_no in('"
									+ bcc.getMobile() + "')";// 定義sql
						}
						try {
							uemo_sts_num = dao.findCountBySql(sql);// 執行sql返回一條字符串
						} catch (Exception e) {
							e.printStackTrace();
						}
						if (uemo_sts_num != 0) {
							co.setUemo_sts("DON’T CALL");// 查到輸出對象中
						}
					}
					list_Contact.add(co);// 將轉換後的對象加到列表中
				}
				cus.setContact(list_Contact);// 將列表加到輸出對象中
			}
		}
		return cus;

	}

}
