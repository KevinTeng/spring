package com.hkbn.es.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hkbn.es.dao.impl.BaseDaoImpl;
import com.hkbn.es.entity.BcnAddrMaint;
import com.hkbn.es.service.BaseService;
import com.hkbn.es.util.StringUtil;
import com.hkbn.es.vo.Address;
import com.hkbn.es.vo.CustomerAddress;

public class CusAddrServiceImpl implements BaseService {
	private static final Log logger = LogFactory
			.getLog(CusAddrServiceImpl.class);
	private BaseDaoImpl dao;

	public BaseDaoImpl getDao() {
		return dao;
	}

	public void setDao(BaseDaoImpl dao) {
		this.dao = dao;
	}

	public List getObject(Map<String, Object> map, String classname)// 根據map的參數和類名來查詢數據
	{
		String hql = null;// 定義hql語句
		Object[] values = null;// 定義“參數列表”
		StringBuffer sb_hqlBuffer = new StringBuffer("from " + classname
				+ " where 1=1  and currAddr='Y' ");// 定義編輯前的hql語句
		int num = map.size();// 獲取有多少個參數條件
		values = new Object[num];// 根據參數條件的數量創建“參數列表”
		Set<String> keys = map.keySet();// 獲取map裡面所有的key
		Iterator<String> iterator = keys.iterator();// 迭代所有的key
		int i = 0;
		while (iterator.hasNext())// 迭代key
		{
			String s = iterator.next();
			sb_hqlBuffer.append(" and " + s + "=?");// 在hql中加入查詢條件
			values[i] = map.get(s);// “參數列表”修改該參數的值
			System.out.println("values[i]:" + values[i]);
			i++;
		}
		hql = sb_hqlBuffer.toString();// 生成hql語句

		// testing
		logger.info("hql:" + hql);
		logger.info("values:" + values.toString());

		List<Object> list = dao.find_by_hql(hql, values);// 根據hql語句和參數列表查詢結果
		return list;
	}

	public CustomerAddress getResult(Map<String, Object> map)// 根據map查詢需要的數據
	{
		CustomerAddress ca = null;// 定義返回的變量
		List<Address> list_addr = null;// 定義返回的變量的其中一個屬性

		String sql = null;
		if (map.size() == 0)// 判斷是否是條件參數，如果沒有直接返回null
		{
			return null;
		} else {
			List<BcnAddrMaint> list = getObject(map,
					"com.hkbn.es.entity.BcnAddrMaint");// 根據map的參數和類名來查詢數據
			if (list == null || list.size() == 0) {
				return null;
			} else {
				ca = new CustomerAddress();// 創建一個返回對象
				list_addr = new ArrayList<Address>();// 創建一條數據的其中一條屬性實例
				for (int i = 0; i < list.size(); i++)// 循環list將數據庫對象轉換成輸出的對象
				{
					String correct_match_desc = null;
					String building_status = null;
					String plan_code = null;
					String dis_line_no = null;
					String plan_addr = null;

					BcnAddrMaint bam = list.get(i);
					Address address = null;
					address = Address.BcnAddrMaint_To_Address(address, bam);// 將數據庫對象轉換成輸出的對象
					// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
					sql = "SELECT ADDR_FLAG || ' - ' || ADDR_FLAG_DESC  FROM BC_ADDR_FLAG  WHERE ADDR_FLAG = '"
							+ bam.getCorrectMatch() + "'";// 定義sql
					try {
						if (bam.getCorrectMatch() != null) {
							correct_match_desc = dao.getStringBySql(sql);// 執行sql返回一條字符串
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					address.setCorrect_match_desc(correct_match_desc);// 查到輸出對象中
					// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
					sql = "SELECT distinct BUILDING_STATUS_NAME  FROM BCI_BUILDING_ADDRESS_VW WHERE ADDR_CODE ="
							+ bam.getAddrCode() + "";// 定義sql
					try {
						if (bam.getAddrCode() != null && bam.getAddrCode() != 0) {
							building_status = dao.getStringBySql(sql);// 執行sql返回一條字符串
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					address.setBuilding_statu(building_status);
					// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
					sql = "SELECT plan_code || '(' || plan_code_seq || ')' FROM BC_CUS_SERVICE_PLAN WHERE CUS_PLAN_CODE = '"
							+ bam.getCusPlanCode() + "'";// 定義sql
					try {
						if (bam.getCusPlanCode() != null) {
							plan_code = dao.getStringBySql(sql);// 執行sql返回一條字符串
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					address.setPlan_code(plan_code);
					// 因為有些數據無法重一次性hql中查出，所以要另外進行sql查詢
					sql = "SELECT DECODE(to_char("
							+ bam.getLineNo()
							+ "),'1','A','2','B','3','C','4','D','5','E','6','F','7','G',to_char("
							+ bam.getLineNo() + ")) FROM DUAL";// 定義sql
					try {
						if (bam.getLineNo() != null) {

							dis_line_no = dao.getStringBySql(sql);// 執行sql返回一條字符串
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					address.setDis_line_no(dis_line_no);
					// 因為有些數據通過運算的出來
					if (StringUtil.notEmpty(bam.getCusPlanCode() + "")
							&& StringUtil.notEmpty(bam.getCircuitNo())
							&& StringUtil.notEmpty(bam.getLineNo() + "")
							&& "I".equalsIgnoreCase(bam.getAddrType())) {
						plan_addr = "Y";
					} else {
						plan_addr = "N";
					}
					address.setPlan_addr(plan_addr);

					list_addr.add(address);
				}
				ca.setAddresses(list_addr);
				return ca;
			}
		}
	}

}
