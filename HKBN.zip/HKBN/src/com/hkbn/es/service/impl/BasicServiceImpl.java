package com.hkbn.es.service.impl;

public class BasicServiceImpl {

}
