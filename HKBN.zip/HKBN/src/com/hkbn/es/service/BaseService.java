package com.hkbn.es.service;

import java.util.Map;

public interface BaseService {

	public Object getResult(Map<String, Object> map);// 定義一個獲取數據的方法

}
