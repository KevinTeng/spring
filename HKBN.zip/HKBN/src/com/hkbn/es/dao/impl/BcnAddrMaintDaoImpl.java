package com.hkbn.es.dao.impl;


public class BcnAddrMaintDaoImpl extends BaseDaoImpl {

}
