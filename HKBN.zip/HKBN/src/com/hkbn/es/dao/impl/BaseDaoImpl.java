package com.hkbn.es.dao.impl;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hkbn.es.dao.BaseDao;

public class BaseDaoImpl implements BaseDao {
	private static final Log logger = LogFactory.getLog(BaseDaoImpl.class);
	protected JdbcTemplate jdbcTemplate;
	protected SessionFactory sessionFactory;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	// 事务必须是开启的(Required)，否则获取不到
	public Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}

	// 根據sql查詢，結果是一個list裝著map，map裡面對應列明和列的值
	public List findBySql(String sql) {
		List rowSet = null;
		try {
			rowSet = jdbcTemplate.queryForList(sql);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}
		return rowSet;
	}

	// 根據sql查詢，objs是傳進去的參數，結果是一個list裝著map，map裡面對應列明和列的值
	public List findBySql(String sql, Object[] objs) {
		List rowSet = null;
		try {
			rowSet = jdbcTemplate.queryForList(sql, objs);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			for (int i = 0; i < objs.length; i++)
				logger.info("param[" + i + "]=>" + objs[i]);
			throw badSqlEx;
		}
		return rowSet;
	}

	// 查詢sql返回行數
	public int findCountBySql(String sql) {
		try {
			return this.jdbcTemplate.queryForObject(sql, Integer.class);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}
	}

	// 查詢sql返回行數，args是傳進去的參數
	public int findCountBySql(String sql, Object[] args) {
		try {
			return this.jdbcTemplate.queryForObject(sql, args, Integer.class);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			for (int i = 0; i < args.length; i++)
				logger.info("param[" + i + "]=>" + args[i]);
			throw badSqlEx;
		}

	}

	// 查詢sql返回long類型數據
	public long findLongBySql(String sql) {
		try {
			return this.jdbcTemplate.queryForObject(sql, Long.class);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}
	}

	// 查詢sql返回double類型數據
	public Double findDoubleBySql(String sql) {
		try {
			return (Double) this.jdbcTemplate.queryForObject(sql, Double.class);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}
	}

	// 查詢sql返回map，和上面的list差不多，不過他理論上只返回一條數據
	public Map findMapBySql(String sql) {
		try {
			return this.jdbcTemplate.queryForMap(sql);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}
	}

	// 查詢sql返回map，objects是傳進去的參數，和上面的list差不多，不過他理論上只返回一條數據
	public Map findMapBySql(String sql, Object[] objects) {
		try {
			return this.jdbcTemplate.queryForMap(sql, objects);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			for (int i = 0; i < objects.length; i++)
				logger.info("param[" + i + "]=>" + objects[i]);
			throw badSqlEx;
		}
	}

	// 執行update的失去了語句
	public void update(String sql) {
		try {
			jdbcTemplate.update(sql);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}
	}

	// 執行update的失去了語句，obj是傳進去的參數
	public void updateNew(String sql, Object[] obj) {
		try {
			jdbcTemplate.update(sql, obj);
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			for (int i = 0; i < obj.length; i++)
				logger.info("param[" + i + "]=>" + obj[i]);
			throw badSqlEx;
		}
	}

	// 執行sql語句，返回String類型結果
	public String getStringBySql(String sql) {

		try {
			String ret = (String) jdbcTemplate.queryForObject(sql,
					java.lang.String.class);
			return ret;
		} catch (Exception badSqlEx) {
			logger.info("Bad SQL:" + sql);
			throw badSqlEx;
		}

	}

	public void call_procedure(String sql, final String[] param,
			final Object[] outObj) {
		this.jdbcTemplate.execute(sql, new CallableStatementCallback() {
			public Object[] doInCallableStatement(CallableStatement cs)
					throws SQLException, DataAccessException {
				for (int i = 0; i < param.length; i++)
					cs.setString(i + 1, param[i]);
				for (int i = 0; i < outObj.length; i++)
					cs.registerOutParameter(param.length + i + 1, Types.VARCHAR);

				cs.execute();
				for (int i = 0; i < outObj.length; i++) {
					outObj[i] = cs.getString(param.length + 1 + i);
				}
				return outObj;

			}
		}

		);
	}

	/*
	 * public Object findObjectByHql(String hql, Object[] objs) { List objList =
	 * this.find_by_hql(hql, objs); if (objList.size() >= 1) return
	 * objList.get(0); else return null; }
	 */

	public void call_procedure(String sql, final List<Map> param,
			final Object[] outObj) {
		this.jdbcTemplate.execute(sql, new CallableStatementCallback() {
			public Object[] doInCallableStatement(CallableStatement cs)
					throws SQLException, DataAccessException {
				Date now = new Date();
				for (int i = 0; i < param.size(); i++) {
					Map mp = (Map) param.get(i);
					if (mp.get("type").equals("Date")) {
						cs.setDate(i + 1, (java.sql.Date) mp.get("val"));
					} else if (mp.get("type").equals("Long"))
						cs.setLong(i + 1, (Long) mp.get("val"));
					else if (mp.get("type").equals("String"))
						cs.setString(i + 1, (String) mp.get("val"));

				}

				for (int i = 0; i < outObj.length; i++)
					cs.registerOutParameter(param.size() + i + 1, Types.VARCHAR);

				cs.execute();
				for (int i = 0; i < outObj.length; i++) {
					outObj[i] = cs.getString(param.size() + 1 + i);
				}
				return outObj;

			}
		}

		);
	}

	public void call_fuction(String sql, final String[] param,
			final Object[] outObj) {
		this.jdbcTemplate.execute(sql, new CallableStatementCallback() {
			public Object[] doInCallableStatement(CallableStatement cs)
					throws SQLException, DataAccessException {
				cs.registerOutParameter(1, Types.VARCHAR);
				for (int i = 0; i < param.length; i++)
					cs.setString(i + 2, param[i]);
				for (int i = 0; i < outObj.length - 1; i++)
					cs.registerOutParameter(param.length + i + 2, Types.VARCHAR);

				cs.execute();
				outObj[0] = cs.getString(1);
				for (int i = 0; i < outObj.length - 1; i++) {
					outObj[i + 1] = cs.getString(param.length + i + 2);
				}
				return outObj;

			}
		}

		);
	}

	public void batchUpdateBySql(String sql) {
		getSession().createSQLQuery(sql).executeUpdate();

	}

	/*
	 * public void batchUpdateByHql(String hql, Object[] objs) {
	 * getSession().bulkUpdate(hql, objs); }
	 * 
	 * public void saveOrUpdateWithSql(String hql, List objs) {
	 * getSession().bulkUpdate(hql); for (int i = 0; i < objs.size(); i++)
	 * getSession().saveOrUpdate(objs.get(i)); }
	 */
	// hql增加或更改數據庫對象
	public void saveOrUpdate(Object obj) {
		getSession().saveOrUpdate(obj);
	}

	// hql增加數據庫對象
	public void save(Object obj) {
		getSession().save(obj);
	}

	// hql更改數據庫對象
	public void update(Object obj) {
		getSession().update(obj);
	}

	// hql根據id和數據庫對象類型查找
	public Object find_object(String entityClass, Serializable id) {
		return getSession().get(entityClass, id);
	}

	// 根據hql查找對象，values是傳進去的參數
	public List find_by_hql(String hql, Object[] values) {
		// testing
		// 记录info级别的信息
		if (logger.isInfoEnabled()) {
			logger.info("----find_by_hql is called...");
			logger.info("----hql:" + hql);
			logger.info("----values:" + values);
		}

		if (values != null) {
			for (int i = 0; i < values.length; i++) {
				// testing
				logger.info("----vaule " + i + ": " + values[i]);
			}
		}
		Query queryObject = this.getSession().createQuery(hql);
		// testing
		logger.info("----queryObject:" + queryObject);

		if (values != null) {
			for (int i = 0; i < values.length; i++) {
				// testing
				logger.info("----vaule " + i + values[i]);
				queryObject.setParameter(i, values[i]);
			}
		}
		List objects = queryObject.list();
		return objects;
	}

	// 根據hql查找對象
	public List find_by_hql(String hql) {
		Query queryObject = this.getSession().createQuery(hql);
		List objects = queryObject.list();
		return objects;
	}

	/*
	 * public List find_by_criteria(DetachedCriteria criteria) {
	 * 
	 * hibernateTemplate.findByCriteria (DetachedCriteria,first,max) 换成
	 * DetachedCriteria .getExecutableCriteria(sessionFactory.getCurrentSession
	 * ()).setFirstResult(first).setMaxResults(max).list()
	 * 
	 * 直接使用 sessionFactory.getCurrentSession().createCriteria(XXX.class) 代替
	 * DetachedCriteria 是最简单的了
	 * 
	 * List objects = this.getSession().findByCriteria(criteria); return
	 * objects; }
	 * 
	 * public List find_by_criteria(DetachedCriteria criteria, int page, int
	 * pageSize) { List objects = this.getSession().findByCriteria(criteria,
	 * page, pageSize); return objects; }
	 */
	// hql刪除對象
	public void delete(Object entity) {
		this.getSession().delete(entity);
	}

	// hql推送
	public void flush() {
		this.getSession().flush();
	}

}
