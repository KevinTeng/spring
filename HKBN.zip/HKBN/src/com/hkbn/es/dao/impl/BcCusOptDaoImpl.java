package com.hkbn.es.dao.impl;


public class BcCusOptDaoImpl extends BaseDaoImpl {

}
