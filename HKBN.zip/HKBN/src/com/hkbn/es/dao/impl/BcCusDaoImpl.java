package com.hkbn.es.dao.impl;


public class BcCusDaoImpl extends BaseDaoImpl {

}
