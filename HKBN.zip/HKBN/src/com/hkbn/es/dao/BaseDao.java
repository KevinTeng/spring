package com.hkbn.es.dao;

import java.io.Serializable;

import java.util.List;
import java.util.Map;

public interface BaseDao {

	/*
	 * sql
	 */
	public List findBySql(String sql);

	public List findBySql(String sql, Object[] objs);

	public int findCountBySql(String sql);

	public int findCountBySql(String sql, Object[] args);

	public long findLongBySql(String sql);

	public Double findDoubleBySql(String sql);

	public Map findMapBySql(String sql);

	public Map findMapBySql(String sql, Object[] objects);

	public void update(String sql);

	public void updateNew(String sql, Object[] obj);

	public String getStringBySql(String sql);

	public void call_procedure(String sql, String[] param, Object[] outObj);

	public void call_procedure(String sql, List<Map> param, Object[] outObj);

	public void call_fuction(String sql, String[] param, Object[] outObj);

	public void batchUpdateBySql(String sql);

	/*
	 * hql
	 */
	public void saveOrUpdate(Object obj);

	public void save(Object obj);

	public void update(Object obj);

	public Object find_object(String entityClass, Serializable id);

	public List find_by_hql(String hql, Object[] values);

	public List find_by_hql(String hql);

	public void delete(Object entity);

	public void flush();
}
