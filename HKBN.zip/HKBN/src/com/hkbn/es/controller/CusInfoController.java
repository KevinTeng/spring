package com.hkbn.es.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hkbn.es.service.BaseService;
import com.hkbn.es.util.DateUtil;
import com.hkbn.es.util.SixNumber;
import com.hkbn.es.util.StringUtil;
import com.hkbn.es.util.UrlCode;
import com.hkbn.es.vo.CustomerContact;

@Controller
@RequestMapping("/customer/cus_info")
public class CusInfoController {
	private static final Log logger = LogFactory
			.getLog(CusInfoController.class);

	private BaseService baseService;

	public BaseService getBaseService() {
		return baseService;
	}

	@Autowired
	@Qualifier("cusInfoServiceImpl")
	public void setBaseService(BaseService baseService) {
		this.baseService = baseService;
	}

	/**
	 * get all customer info
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	public @ResponseBody
	CustomerContact[] getAllCusInfo() {
		// testing
		logger.info("----Get all cus_info");
		// baseService.getAllCus();
		return null;
	}

	// GET類型請求
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	// 輸出json格式
	public @ResponseBody
	CustomerContact getCusInfoById(@PathVariable(value = "id") String pps) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值

		// testing
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("pps", pps);
		logger.info("----Before decode:" + map2.entrySet());

		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecodeToUTF8(pps)));// 把它放到map裡面，注意要去除'號
		}

		// testing
		logger.info("----After decode:" + map.entrySet());

		CustomerContact cus = (CustomerContact) baseService.getResult(map);// 根據map的參數查詢出結果
		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (cus != null)// 看剛才查詢的結果是否為null
		{
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			cus.setResp_sts("1");
		} else {
			cus = new CustomerContact();// 如果為null，從新創建對象再加上時間和查詢結果狀態
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			cus.setResp_sts("0");
		}
		// testing
		logger.info("----company:" + cus.getCompany());
		logger.info("----company_chinese:" + cus.getCompany_chinese());
		return cus;
	}

	/**
	 * get customer info by criteria
	 */
	@RequestMapping(value = "/search", method = { RequestMethod.GET,
			RequestMethod.POST })
	// 輸出json格式
	public @ResponseBody
	CustomerContact getCusInfoBy(
			@RequestParam(value = "pps", required = false) String pps,
			@RequestParam(value = "customer_name", required = false) String customer_name,
			@RequestParam(value = "br_number", required = false) String br_number) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值

		// testing
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("pps", pps);
		map2.put("company", customer_name);
		map2.put("brno", br_number);
		logger.info("----Before decode:" + map2.entrySet());

		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecodeToUTF8(pps)));// 把它放到map裡面，注意要去除'號
		}
		if (StringUtil.notEmpty(customer_name)) {
			map.put("company", StringUtil.deleteComma(UrlCode
					.urlDecodeToUTF8(customer_name)));
		}
		if (StringUtil.notEmpty(br_number)) {
			map.put("brno",
					StringUtil.deleteComma(UrlCode.urlDecodeToUTF8(br_number)));
		}

		// testing
		logger.info("----After decode:" + map.entrySet());

		CustomerContact cus = (CustomerContact) baseService.getResult(map);// 根據map的參數查詢出結果
		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (cus != null)// 看剛才查詢的結果是否為null
		{
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			cus.setResp_sts("1");
		} else {
			cus = new CustomerContact();// 如果為null，從新創建對象再加上時間和查詢結果狀態
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			cus.setResp_sts("0");
		}
		// testing
		logger.info("----company:" + cus.getCompany());
		logger.info("----company_chinese:" + cus.getCompany_chinese());
		return cus;
	}

}
