package com.hkbn.es.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hkbn.es.service.BaseService;
import com.hkbn.es.util.DateUtil;
import com.hkbn.es.util.SixNumber;
import com.hkbn.es.util.StringUtil;
import com.hkbn.es.util.UrlCode;
import com.hkbn.es.vo.CusOpt;

@Controller
@RequestMapping("/customer/cus_opt")
public class CusOptController {

	private BaseService baseService;

	public BaseService getBaseService() {
		return baseService;
	}

	@Autowired
	@Qualifier("cusOptServiceImpl")
	public void setBaseService(BaseService baseService) {
		this.baseService = baseService;
	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public @ResponseBody
	CusOpt getAllCusOpt(@RequestParam("pps") String pps) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值
		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecode(pps)));// 把它放到map裡面，注意要去除'號
		}
		CusOpt co = (CusOpt) baseService.getResult(map);// 根據map的參數查詢出結果
		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (co != null)// 看剛才查詢的結果是否為null
		{
			co.setPps(pps);
			co.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			co.setResp_sts("1");
		} else {
			co = new CusOpt();// 如果為null，從新創建對象再加上時間和查詢結果狀態
			co.setPps(pps);
			co.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			co.setResp_sts("0");
		}
		return co;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public @ResponseBody
	CusOpt getCusOptById(@PathVariable("id") String pps) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值
		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecode(pps)));// 把它放到map裡面，注意要去除'號
		}
		CusOpt co = (CusOpt) baseService.getResult(map);// 根據map的參數查詢出結果
		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (co != null)// 看剛才查詢的結果是否為null
		{
			co.setPps(pps);
			co.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			co.setResp_sts("1");
		} else {
			co = new CusOpt();// 如果為null，從新創建對象再加上時間和查詢結果狀態
			co.setPps(pps);
			co.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			co.setResp_sts("0");
		}
		return co;
	}

	/**
	 * get customer opt by pps
	 */
	@RequestMapping(value = "/search", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody
	CusOpt getCusOptByPps(@RequestParam("pps") String pps) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值
		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecode(pps)));// 把它放到map裡面，注意要去除'號
		}
		CusOpt co = (CusOpt) baseService.getResult(map);// 根據map的參數查詢出結果
		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (co != null)// 看剛才查詢的結果是否為null
		{
			co.setPps(pps);
			co.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			co.setResp_sts("1");
		} else {
			co = new CusOpt();// 如果為null，從新創建對象再加上時間和查詢結果狀態
			co.setPps(pps);
			co.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			co.setResp_sts("0");
		}
		return co;
	}

}
