package com.hkbn.es.controller;

public class RestURIConstants {

	public static final String DUMMY_EMP = "/rest/emp/dummy";
	public static final String GET_EMP = "/rest/emp/{id}";
	public static final String GET_ALL_EMP = "/rest/emps";
	public static final String CREATE_EMP = "/rest/emp/create";
	public static final String DELETE_EMP = "/rest/emp/delete/{id}";

	// customer
	public static final String CUSTOMER = "/customer";
	// CUS_ADDR
	public static final String GET_ALL_CUS_ADDR = "/customer/cus_addr";
	public static final String GET_CUS_ADDR = "/customer/cus_addr/{id}";
	public static final String SEARCH_CUS_ADDR = "/customer/cus_addr/search";
	public static final String CREATE_CUS_ADDR = "/customer/cus_addr/create";
	public static final String UPDATE_CUS_ADDR = "/customer/cus_addr/update/{id}";
	public static final String DELETE_CUS_ADDR = "/customer/cus_addr/delete/{id}";
	// CUS_INFO
	public static final String GET_ALL_CUS_INFO = "/customer/cus_info";
	public static final String GET_CUS_INFO = "/customer/cus_info/{id}";
	public static final String SEARCH_CUS_INFO = "/customer/cus_info/search";
	public static final String CREATE_CUS_INFO = "/customer/cus_info/create";
	public static final String UPDATE_CUS_INFO = "/customer/cus_info/update/{id}";
	public static final String DELETE_CUS_INFO = "/customer/cus_info/delete/{id}";
	// CUS_OPT
	public static final String GET_ALL_CUS_OPT = "/customer/cus_opt";
	public static final String GET_CUS_OPT = "/customer/cus_opt/{id}";
	public static final String SEARCH_CUS_OPT = "/customer/cus_opt/search";
	public static final String CREATE_CUS_OPT = "/customer/cus_opt/create";
	public static final String UPDATE_CUS_OPT = "/customer/cus_opt/update/{id}";
	public static final String DELETE_CUS_OPT = "/customer/cus_opt/delete/{id}";

}
