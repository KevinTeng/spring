package com.hkbn.es.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hkbn.es.model.UserModel;

@Controller
@RequestMapping(value = "/login")
public class LoginController {
	private static final Log logger = LogFactory.getLog(LoginController.class);

	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView loginValidate(
			@RequestParam(value = "username", required = false) String username,
			@RequestParam(value = "password", required = false) String password) {
		logger.info("----login controller is called...");
		UserModel user = new UserModel(); // 用于转换到form表单的对象
		user.setUsername(username);
		ModelAndView mav = new ModelAndView();

		if (username.equals("u_cs_001") && password.equals("u_cs_001")) {
			logger.info("----login successfully...");
			mav.setViewName("success");// 设置返回的视图名称
		} else {
			logger.info("----login failed...");
			mav.setViewName("redirect:index");
		}

		mav.addObject("user", user);// model对象
		return mav;
	}
}
