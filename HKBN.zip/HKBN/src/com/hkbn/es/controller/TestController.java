package com.hkbn.es.controller;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hkbn.es.test.Preferences;

@Controller
@RequestMapping(value = "/rest")
public class TestController {

	@RequestMapping(value = "/form", method = RequestMethod.GET)
	public ModelAndView testForm() {
		Preferences preferences = new Preferences(); // 用于转换到form表单的对象
		ModelAndView mav = new ModelAndView();
		mav.setViewName("form");// 设置返回的视图名称
		mav.addObject("preferences", preferences);// model对象
		return mav;

	}

	// get testing
	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public @ResponseBody
	String get() {
		System.out.println("get method called...");
		return "get data successfully!";
	}

	// post testing
	@RequestMapping(value = "/post", method = RequestMethod.POST)
	public void post(HttpServletRequest request, @RequestParam String[] pps,
			@RequestParam String[] name) {

		System.out.println("post method called...");
		if (pps != null) {
			for (int i = 0; i < pps.length; i++)
				System.out.println(pps[i]);
		}
		if (name != null) {
			for (int i = 0; i < name.length; i++)
				System.out.println(name[i]);
		}
		Map map = request.getParameterMap();
		System.out.println("map:" + map.entrySet());
	}

	// put testing
	@RequestMapping(value = "/put", method = RequestMethod.PUT)
	public void put(@RequestBody String body, Writer writer) throws IOException {
		System.out.println("put method called...");
		System.out.println(body);
		writer.write(body);
	}

	// delete testing
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public void delete() {
		System.out.println("delete method called...");
	}
}
