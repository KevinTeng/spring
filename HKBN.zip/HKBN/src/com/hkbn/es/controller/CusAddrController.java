package com.hkbn.es.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hkbn.es.service.BaseService;
import com.hkbn.es.util.DateUtil;
import com.hkbn.es.util.SixNumber;
import com.hkbn.es.util.StringUtil;
import com.hkbn.es.util.UrlCode;
import com.hkbn.es.vo.CustomerAddress;

@Controller
@RequestMapping("/customer/cus_addr")
public class CusAddrController {
	private static final Log logger = LogFactory
			.getLog(CusAddrController.class);

	private BaseService baseService;

	public BaseService getBaseService() {
		return baseService;
	}

	@Autowired
	@Qualifier("cusAddrServiceImpl")
	public void setBaseService(BaseService baseService) {
		this.baseService = baseService;
	}

	/**
	 * get all customer address
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	// 輸出json格式
	public @ResponseBody
	CustomerAddress getAllCusAddr(
			@RequestParam(value = "pps", required = false) String pps) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值
		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecode(pps)));// 把它放到map裡面，注意要去除'號
		}

		// testing
		logger.info("----get all cus_addr");
		logger.info("----pps:" + pps);
		logger.info("----map:" + map);
		logger.info("----bean:" + baseService);
		CustomerAddress cus = (CustomerAddress) baseService.getResult(map);// 根據map的參數查詢出結果

		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (cus != null)// 看剛才查詢的結果是否為null
		{
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			cus.setPps(pps);
			cus.setResp_sts("1");
		} else {
			cus = new CustomerAddress();
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果為null，從新創建對象再加上時間和查詢結果狀態
			cus.setPps(pps);
			cus.setResp_sts("0");
		}
		return cus;
	}

	/**
	 * get specific customer address
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	// 輸出json格式
	public @ResponseBody
	CustomerAddress getCusAddrById(@PathVariable("id") String pps) {
		Map<String, Object> map = new HashMap<String, Object>();// 創建一個map來裝參數，key是hql查詢的屬性名，value是傳過來的值
		if (StringUtil.notEmpty(pps))// 判斷參數的值是否是null
		{
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecode(pps)));// 把它放到map裡面，注意要去除'號
		}

		// testing
		logger.info("----get cus_addr. id = " + pps);
		logger.info("----pps:" + pps);
		logger.info("----map:" + map);
		logger.info("----bean:" + baseService);
		CustomerAddress cus = (CustomerAddress) baseService.getResult(map);// 根據map的參數查詢出結果

		String dateString = DateUtil.formattime("yyyyMMdd");// 獲取當前時間
		if (cus != null)// 看剛才查詢的結果是否為null
		{
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果不為null，加上時間和查詢結果狀態
			cus.setPps(pps);
			cus.setResp_sts("1");
		} else {
			cus = new CustomerAddress();
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());// 如果為null，從新創建對象再加上時間和查詢結果狀態
			cus.setPps(pps);
			cus.setResp_sts("0");
		}
		return cus;
	}

	/**
	 * search customer address by pps
	 */
	@RequestMapping(value = "/search", method = { RequestMethod.POST,
			RequestMethod.GET })
	public @ResponseBody
	CustomerAddress getCusAddrByPps(@RequestParam(value = "pps") String pps) {
		Map<String, Object> map = new HashMap<String, Object>();
		if (StringUtil.notEmpty(pps)) {
			map.put("pps", StringUtil.deleteComma(UrlCode.urlDecode(pps)));
		}

		// testing
		logger.info("----search customer address by pps");
		logger.info("----pps:" + pps);
		logger.info("----map:" + map);
		logger.info("----bean:" + baseService);
		CustomerAddress cus = (CustomerAddress) baseService.getResult(map);

		String dateString = DateUtil.formattime("yyyyMMdd");
		if (cus != null) {
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			cus.setPps(pps);
			cus.setResp_sts("1");
		} else {
			cus = new CustomerAddress();
			cus.setTxn_id(dateString + "_" + SixNumber.getSixNumber());
			cus.setPps(pps);
			cus.setResp_sts("0");
		}
		return cus;
	}

}
