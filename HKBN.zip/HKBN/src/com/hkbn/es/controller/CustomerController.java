package com.hkbn.es.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(RestURIConstants.CUSTOMER)
public class CustomerController {
	private static final Log logger = LogFactory
			.getLog(CustomerController.class);

	@RequestMapping(value = "", method = RequestMethod.GET)
	public ModelAndView list(HttpServletRequest request, Model model) {
		logger.info("----customer controller is called...");
		return new ModelAndView("customer/index");
	}

	// cus_info
	@RequestMapping(value = "/cus_info_home", method = RequestMethod.GET)
	public ModelAndView cus_info(HttpServletRequest request, Model model) {
		logger.info("----cus_info controller is called...");
		return new ModelAndView("customer/cus_info");
	}

	// cus_addr
	@RequestMapping(value = "/cus_addr_home", method = RequestMethod.GET)
	public ModelAndView cus_addr(HttpServletRequest request, Model model) {
		logger.info("----cus_addr controller is called...");
		return new ModelAndView("customer/cus_addr");
	}

	// cus_opt
	@RequestMapping(value = "/cus_opt_home", method = RequestMethod.GET)
	public ModelAndView cus_opt(HttpServletRequest request, Model model) {
		logger.info("----cus_opt controller is called...");
		return new ModelAndView("customer/cus_opt");
	}
}
