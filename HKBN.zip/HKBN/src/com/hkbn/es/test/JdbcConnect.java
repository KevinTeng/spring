package com.hkbn.es.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnect//測試數據庫連接
{
	public static void main(String[] args)
	{
		Connection connection = null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");

			connection = DriverManager.getConnection(
					"dbc:oracle:thin:@192.168.67.21:1521:INCBN", "inc",
					"inc123a");
			System.out.println(connection);

			Statement statement = connection.createStatement();
			ResultSet resultSet = statement
					.executeQuery("select bccus0_.PPS as PPS0_, bccus0_.COMPANY as COMPANY0_, bccus0_.BRNO as BRNO0_, bccus0_.CREATE_DATE as CREATE4_0_, bccus0_.AMEND_DATE as AMEND5_0_, bccus0_.STAFF_CREATE as STAFF6_0_, bccus0_.STAFF_AMEND as STAFF7_0_, bccus0_.PROGRAM as PROGRAM0_, bccus0_.CTI_CUS_TYPE as CTI9_0_, bccus0_.CTI_OD as CTI10_0_, bccus0_.TELEPHONE as TELEPHONE0_, bccus0_.IDD_AC as IDD12_0_, bccus0_.CRE_LIMIT as CRE13_0_, bccus0_.PREVIOUS_ISP as PREVIOUS14_0_, bccus0_.PREV_INT_CONN as PREV15_0_, bccus0_.STATUS as STATUS0_, bccus0_.VIP as VIP0_, bccus0_.COMPANY_CHINESE as COMPANY18_0_, bccus0_.TENDER as TENDER0_, bccus0_.PREMIUM as PREMIUM0_, bccus0_.NICKNAME as NICKNAME0_, bccus0_.WHOLESALE_FLAG as WHOLESALE22_0_ from INC.BC_CUS bccus0_ where 1 = 1 and bccus0_.BRNO = '10893326-000-02-99-0' and bccus0_.COMPANY = 'TECHNOSOFT HK LTD' and bccus0_.PPS = '000342716'");
			int i = 0;
			while (resultSet.next())
			{
				i++;
			}
			System.out.println(i);

		} catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e)
		{
			e.printStackTrace();
		} finally
		{
			if (connection != null)
			{
				try
				{
					connection.close();
				} catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
}
