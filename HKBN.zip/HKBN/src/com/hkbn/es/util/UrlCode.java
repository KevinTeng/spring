package com.hkbn.es.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class UrlCode {
	private static final Log logger = LogFactory.getLog(UrlCode.class);

	public static String urlEncode(String str) {

		try {
			str = URLEncoder.encode(str, "UTF-8");
			return str;
		} catch (UnsupportedEncodingException e) {
			logger.error("url編碼出問題");
			return "";
		}
	}

	/**
	 * 调用decode前先确保调用encode，目的在于消除java将"+"编码成" "的影响
	 * 
	 * @param str
	 * @return
	 */
	public static String urlDecode(String str) {
		try {
			str = URLEncoder.encode(str, "UTF-8");
			str = URLDecoder.decode(str, "UTF-8");
			return str;

		} catch (UnsupportedEncodingException e) {
			logger.error("url解碼出問題");
			return "";
		}
	}

	/*
	 * 默认情况下spring mvc的编码方式为 "ISO-8859-1"，参数的中文会出现乱码，需转码处理
	 */
	public static String urlDecodeToUTF8(String str) {
		byte[] rawBytes;
		try {
			str = urlDecode(str);// 处理&+等特殊字符
			rawBytes = str.getBytes("ISO-8859-1");// 以"ISO-8859-1"方式解析字符串
			str = new String(rawBytes, "UTF-8"); // 转换为"utf-8"格式,解析中文字符串
			return str;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			logger.error("url解碼出問題");
			return "";
		}
	}

	/*
	 * 中文转码
	 */
	public static String stringToUTF8(String str) {
		byte[] rawBytes;
		try {
			rawBytes = str.getBytes("ISO-8859-1");// 以"ISO-8859-1"方式解析字符串
			str = new String(rawBytes, "UTF-8"); // 转换为"utf-8"格式,解析中文字符串
			return str;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			logger.error("url解碼出問題");
			return "";
		}
	}

}
