package com.hkbn.es.util;

public class SixNumber// 生成6位數字符串
{
	private static String date = DateUtil.formattime("yyyyMMdd");
	private static int num = 1;

	private static int getnum()// 判斷是否當天。如果是新一天數字重新開始
	{
		if (date == null) {
			date = DateUtil.formattime("yyyyMMdd");
		}
		if (!date.equals(DateUtil.formattime("yyyyMMdd"))) {
			num = 0;
		}
		return num;

	}

	public static String getSixNumber()// 輸出6位數字符串
	{
		String str = getnum() + 1000000 + "";
		str = str.substring(1, str.length());
		num++;
		if (num >= 1000000)// 判斷是否大於6位數，否則從新開始
		{
			num = 1;
		}
		return str;
	}
}
