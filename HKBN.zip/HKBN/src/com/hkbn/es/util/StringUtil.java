package com.hkbn.es.util;

public class StringUtil {

	public static boolean notEmpty(String str)// 檢查String是不是空
	{
		if (str != null && str.trim().length() != 0
				&& !"null".equalsIgnoreCase(str.trim())) {
			return true;
		} else {
			return false;
		}
	}

	public static String changeNull(String str)// 將空變為""
	{
		if (str == null || "null".equalsIgnoreCase(str.trim())) {
			return "";
		} else {
			return str;
		}
	}

	public static String deleteComma(String str)// 去掉前後的單引號和雙引號
	{
		if (!notEmpty(str)) {
			return str;
		}
		String start = str.charAt(0) + "";
		String end = str.charAt(str.length() - 1) + "";

		if (start.equalsIgnoreCase(end)
				&& ("'".equals(start) || "\"".equals(start))) {
			return str.substring(1, str.length() - 1);
		} else {
			return str;
		}

	}

}
