package com.hkbn.es.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil
{
	public static String formattime(Date date, String fmt)// 輸入Date和格式類型返回字符串
	{
		if (fmt == null || "".equals(fmt.trim()) || date == null)
		{
			return null;
		} else
		{
			SimpleDateFormat sdf = new SimpleDateFormat(fmt);
			String string = sdf.format(date);
			return string;
		}
	}

	public static String formattime(String fmt)// 輸入格式類型返回當前時間的字符串
	{
		if (fmt == null || "".equals(fmt.trim()))
		{
			return null;
		} else
		{
			Date date = new Date();
			return formattime(date, fmt);
		}
	}

}
